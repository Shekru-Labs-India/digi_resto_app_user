import React, { useEffect, useState } from "react";
import { useRestaurantId } from "../context/RestaurantIdContext";

const HomeScreen = () => {
  const { restaurantId, loading, error } = useRestaurantId();
  const [categories, setCategories] = useState([]);
  const [menuItems, setMenuItems] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState(null);

  useEffect(() => {
    if (!restaurantId) return;

    const fetchCategories = async () => {
      try {
        const response = await fetch(
          `https://api.yoursite.com/get_categories/${restaurantId}`
        );
        const data = await response.json();
        setCategories(data.categories);
      } catch (err) {
        console.error("Failed to fetch categories", err);
      }
    };

    const fetchMenuItems = async () => {
      if (!selectedCategory) return;

      try {
        const response = await fetch(
          `https://api.yoursite.com/get_menu_items/${restaurantId}/${selectedCategory}`
        );
        const data = await response.json();
        setMenuItems(data.items);
      } catch (err) {
        console.error("Failed to fetch menu items", err);
      }
    };

    fetchCategories();
    fetchMenuItems();
  }, [restaurantId, selectedCategory]);

  if (loading) return <div>Loading...</div>;
  if (error) return <div>{error}</div>;

  return (
    <div>
      <h1>{restaurantId ? "Restaurant Name" : "Loading Restaurant..."}</h1>
      <div>
        <h2>Menu Category</h2>
        <div>
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => setSelectedCategory(category.id)}
              className={selectedCategory === category.id ? "active" : ""}
            >
              {category.name}
            </button>
          ))}
        </div>
      </div>

      <div>
        {menuItems.length > 0 ? (
          menuItems.map((item) => (
            <div key={item.id}>
              <img src={item.image} alt={item.name} />
              <h3>{item.name}</h3>
              <p>{item.description}</p>
              <p>
                <del>{item.original_price}</del> {item.discounted_price}
              </p>
              <button>Add To Cart</button>
            </div>
          ))
        ) : (
          <p>No menu items available in this category.</p>
        )}
      </div>
    </div>
  );
};

export default HomeScreen;
