import React from 'react'

const Restoname = () => {
  return (
    <div>
     MenuMitra
    </div>
  )
}

export default Restoname
