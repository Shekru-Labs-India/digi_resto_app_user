import React from 'react'

const CompanyVersion = () => {
  return (
   
    <div className='footer-fixed-btn1 '>
      <p className='company' >Shekru Labs India Pvt.Ltd  <p className='company' >v1</p></p>
   
    </div>
  )
}

export default CompanyVersion
